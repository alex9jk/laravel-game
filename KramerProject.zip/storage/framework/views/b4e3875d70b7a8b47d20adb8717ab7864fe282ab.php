<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
                <!-- <h2 class="header">Welcome <strong><?php echo e($user->name); ?> </strong>to Connect 4 Lobby</h2>
       
            <div class="outer">
                <div class="box" id="box">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                  
                </div>   
            </div>  -->
            <h2 id="tableHead">Game Table</h2>
            
            <table id="profileTable" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th>Start Date</th>
                        <th>Player 1 ID</th>
                        <th>Player 2 ID</th>
                        <th>Status</th>
                        <th>Winner</th>

                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($game->created_at); ?></td>
                      <td><?php echo e($game->player1ID); ?></td>
                      <td><?php echo e($game->player2ID); ?></td>
                      <td><?php echo e($game->gameState); ?></td>
                      <td><?php echo e($game->winner); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>


            </table>
            <a href="home" class="btn btn-primary">Proceed to Game Lobby</a>
            </div>
        </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravelProject\resources\views/profile.blade.php ENDPATH**/ ?>