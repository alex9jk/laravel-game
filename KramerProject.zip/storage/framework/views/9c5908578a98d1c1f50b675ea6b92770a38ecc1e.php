<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row ">
        <div class="col-md-8">
                <h2 class="header"><strong>Play Connect Four</strong></h2>
                <div><h5 id="whosTurn"></h5></div>
        <div id= "wrapper">    
            <div>    
                <div class="box">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>            
                </div>
                <div id ="stretch">
                    <form method="POST" class="chatSend">
                        <input type="text" id="messageBox" name="message" min="50" class="form-control" />
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                        <input type="submit" name="chat" value="send" class="submit btn btn-primary"/>
                        <input type="hidden" name= "gameid"value="<?php echo e($game->id); ?>" />
                    </form>
                </div>
            </div>
                
                <div class= "boardContainer">
                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="560px" height="560px" class="svgClass" >
                    <?php for($i=0; $i < 7;$i++): ?>
                        <rect x="<?php echo e(((80 * $i))); ?> " y="0" width="80px" height="80px" fill="transparent" stroke-width="2px" stroke="black" />
                    <?php endfor; ?>
                        <g id="group" width="560px" x="0" y="0">
                        </g>
                    
                    <?php for($i = 0; $i < 7; $i++): ?>
                        <?php for($j = 1; $j < 7; $j++): ?>
                            <rect x="<?php echo e((0 + (80 * $i))); ?> " y="<?php echo e((0 + (80 * $j))); ?>" width="80px" height="80px" fill="navy" stroke-width="2px" stroke="black" id="<?php echo e('target' . $i .($j -1)); ?>"/>
                            <circle cx="<?php echo e((40 + (80 * $i))); ?> " cy="<?php echo e((40 + (80 * $j))); ?>" r="25" fill="white" />
                        <?php endfor; ?>
                    <?php endfor; ?>
                    </svg>
                </div> 
                
            </div>   
        </div>
    </div>
</div>

<script>var gameid="<?php echo e($game->id); ?>";</script>
<script src="<?php echo e(asset('js/game.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravelProject\resources\views/game/playgame.blade.php ENDPATH**/ ?>