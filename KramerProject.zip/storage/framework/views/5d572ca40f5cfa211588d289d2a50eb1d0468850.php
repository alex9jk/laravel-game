<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
                <h2 class="header">Welcome <strong><?php echo e($user->name); ?> </strong>to Connect Four Lobby</h2>
        <div id="flex">
            <div class="outer">
                <div class="box" id="box">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                  
                </div>  
                <div id="form-div">
                            <form method="POST" class="chatSend">
                                <input type="text" name="message" class="form-control" min="50" id="messageInput"/>
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                                <input type="submit" name="chat" value="send"class="submit btn btn-primary"/>
                            </form>
                        </div>
                </div>
                <div>
                    <h5>Available Users to Play</h5>
                    <div id="waiting-users"></div>
                </div>
                
            </div>
            <a href="../public" class="btn btn-primary">Go back to Game Table</a>  
            </div>

        </div>
</div>

<script src="<?php echo e(asset('js/lobby.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravelProject\resources\views/home.blade.php ENDPATH**/ ?>