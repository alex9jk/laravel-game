<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateGamesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('games', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->timestamps();
            $table->unsignedBigInteger('player1ID')->nullable();
            $table->foreign('player1ID')->references('id')->on('users');
            $table->unsignedBigInteger('player2ID')->nullable();
            $table->foreign('player2ID')->references('id')->on('users');
            $table->json('boardArray')->nullable();
            $table->string('gameState');
            $table->bigInteger('playerTurn')->nullable();
            $table->unsignedBigInteger('winner')->nullable()->default(null);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('games');
    }
}
